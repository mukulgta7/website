const route = require('express').Router()

route.get('/', async (req, res) => {

    res.render('index1')
});

    module.exports = route
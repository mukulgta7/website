const route = require('express').Router()

route.get('/', async (req, res) => {

    res.render('cars');
});
module.exports = route
const route = require('express').Router()

route.get('/', async (req, res) => {

    res.render('index');
});
module.exports = route
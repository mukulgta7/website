const express = require('express');
const session = require('express-session');

const app = express();

app.set('view engine', 'hbs');


app.use(session({
    resave: false,
    saveUninitialized: false,
    secret: 'something very very secret'
}));

app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.use(express.static('views/images'));
app.use('/index', require('./routes/index'));
app.use('/index1', require('./routes/index1'));
app.use('/cars', require('./routes/cars'));
app.use('/signup', require('./routes/signup'));
app.use('/login', require('./routes/login'));
app.use('/logout', require('./routes/logout'));
app.use('/feed', require('./routes/feed'));
app.use('/profile', require('./routes/profile'));
app.use('/', require('./routes/root'));


app.listen(3939, function () {
    console.log("Server started on http://localhost:3939");
});